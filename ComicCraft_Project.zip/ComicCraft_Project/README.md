# ComicCraft – AI Comic Story Creator

Complete FastAPI + Jinja2 implementation based on the supplied ComicCraft documentation. The documented design uses Gemini for comic story/narration/dialogue and Stable Diffusion/Diffusers for comic illustrations.

## VS Code / Windows
```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
copy .env.example .env
uvicorn app.main:app --reload
```
Open `http://127.0.0.1:8000` and `/docs`.

Put your Gemini key in `.env`. `HF_TOKEN` is optional; without it the app creates local fallback panel images so the complete UI/PDF pipeline can still be demonstrated.

Run tests: `pytest -q`

Administrator mode is normally unnecessary. If Windows permissions cause an error, open PowerShell/Windows Terminal as Administrator and run the same commands.

The source documentation references older model IDs, so model names are configurable in `.env`.
