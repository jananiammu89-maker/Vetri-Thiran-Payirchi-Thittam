from pydantic import BaseModel,Field
class ComicRequest(BaseModel):
 story_prompt:str=Field(min_length=5,max_length=3000)
 character_name:str=Field(min_length=1,max_length=100)
 setting:str=Field(min_length=1,max_length=200)
 tone:str=Field(min_length=1,max_length=80)
 art_style:str=Field(min_length=1,max_length=100)
 panels:int=Field(default=6,ge=3,le=10)
