from fpdf import FPDF
def make_pdf(story,images,out):
 pdf=FPDF();pdf.set_auto_page_break(auto=True,margin=15)
 for i,p in enumerate(story['panels']):
  pdf.add_page();pdf.set_font('Helvetica','B',18);pdf.cell(0,12,story['title'],ln=True,align='C');pdf.set_font('Helvetica','B',14);pdf.cell(0,10,f"Panel {p['number']}: {p['title']}",ln=True)
  if images[i].endswith('.png'):pdf.image(images[i],x=15,y=45,w=180)
  pdf.set_y(150);pdf.set_font('Helvetica',size=11);pdf.multi_cell(0,7,'NARRATION: '+p['narration']);pdf.ln(3);pdf.multi_cell(0,7,'DIALOGUE: '+p['dialogue'])
 pdf.output(out);return out
