import os
from dotenv import load_dotenv
load_dotenv()
GEMINI_API_KEY=os.getenv('GEMINI_API_KEY','')
GEMINI_MODEL=os.getenv('GEMINI_MODEL','gemini-2.5-flash')
HF_TOKEN=os.getenv('HF_TOKEN','')
HF_IMAGE_MODEL=os.getenv('HF_IMAGE_MODEL','stabilityai/stable-diffusion-xl-base-1.0')
BASE_URL=os.getenv('APP_BASE_URL','http://127.0.0.1:8000')
GENERATED_DIR=os.path.join(os.path.dirname(os.path.dirname(__file__)),'generated')
