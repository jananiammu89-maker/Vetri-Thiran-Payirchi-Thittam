from pathlib import Path
from fastapi import FastAPI,Request,Form
from fastapi.responses import HTMLResponse,FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import json,uuid
from .schemas import ComicRequest
from .ai_story import generate
from .image_generator import generate as make_image
from .layout_builder import make_pdf
from .config import GENERATED_DIR,BASE_URL
BASE=Path(__file__).resolve().parent.parent
app=FastAPI(title='ComicCraft - AI Comic Story Creator')
app.mount('/static',StaticFiles(directory=BASE/'static'),name='static');app.mount('/media',StaticFiles(directory=GENERATED_DIR),name='media');app.state.templates=Jinja2Templates(directory=BASE/'templates')
@app.get('/',response_class=HTMLResponse)
def home(request:Request):return app.state.templates.TemplateResponse('index.html',{'request':request})
@app.post('/generate',response_class=HTMLResponse)
def generate_page(request:Request,story_prompt:str=Form(...),character_name:str=Form(...),setting:str=Form(...),tone:str=Form(...),art_style:str=Form(...),panels:int=Form(6)):
 req=ComicRequest(story_prompt=story_prompt,character_name=character_name,setting=setting,tone=tone,art_style=art_style,panels=panels);story=generate(req);images=[BASE_URL+'/media/'+Path(make_image(p['image_prompt'],p['number'])).name for p in story['panels']]
 return app.state.templates.TemplateResponse('result.html',{'request':request,'story':story,'images':images})
@app.post('/api/generate')
def api_generate(payload:ComicRequest):
 story=generate(payload);images=[BASE_URL+'/media/'+Path(make_image(p['image_prompt'],p['number'])).name for p in story['panels']];return {'story':story,'images':images}
@app.post('/export')
def export(story_json:str=Form(...)):
 story=json.loads(story_json);from PIL import Image,ImageDraw;imgs=[]
 for p in story['panels']:
  f=Path(GENERATED_DIR)/f"panel_{p['number']}.png"
  if not f.exists():
   im=Image.new('RGB',(1024,768),(30,41,59));ImageDraw.Draw(im).text((80,350),f"ComicCraft Panel {p['number']}",fill='white');im.save(f)
  imgs.append(str(f))
 out=Path(GENERATED_DIR)/f'comiccraft_{uuid.uuid4().hex[:8]}.pdf';make_pdf(story,imgs,str(out));return FileResponse(out,media_type='application/pdf',filename=out.name)
@app.get('/health')
def health():return {'status':'ok','service':'ComicCraft'}
