import json,re
from .config import GEMINI_API_KEY,GEMINI_MODEL
def fallback(req):
 return {'title':req.character_name+' Adventure','panels':[{'number':i,'title':'Panel '+str(i),'narration':f'{req.character_name} continues the adventure in {req.setting}.','dialogue':f'{req.character_name}: Let us keep going!','image_prompt':f'{req.art_style} comic panel, {req.character_name} in {req.setting}, {req.tone} mood'} for i in range(1,req.panels+1)]
def generate(req):
 if not GEMINI_API_KEY:return fallback(req)
 from google import genai
 prompt='Create a cohesive comic story as JSON. Story: '+req.story_prompt+'. Character: '+req.character_name+'. Setting: '+req.setting+'. Tone: '+req.tone+'. Art style: '+req.art_style+f'. Make exactly {req.panels} panels. Return only JSON with title and panels; every panel needs number,title,narration,dialogue,image_prompt.'
 text=genai.Client(api_key=GEMINI_API_KEY).models.generate_content(model=GEMINI_MODEL,contents=prompt).text.strip()
 text=re.sub(r'^```json\s*|^```\s*|\s*```$','',text,flags=re.I)
 try:
  data=json.loads(text)
  if len(data.get('panels',[]))!=req.panels:raise ValueError
  return data
 except Exception:return fallback(req)
