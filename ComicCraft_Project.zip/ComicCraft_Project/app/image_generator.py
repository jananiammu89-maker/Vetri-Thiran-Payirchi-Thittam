from pathlib import Path
from .config import HF_TOKEN,HF_IMAGE_MODEL,GENERATED_DIR

def fallback(path,index):
 svg=f'''<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="768"><rect width="1024" height="768" fill="#172554"/><circle cx="180" cy="180" r="80" fill="#fbbf24"/><rect x="70" y="430" width="884" height="220" rx="30" fill="#000" opacity=".45"/><text x="512" y="520" text-anchor="middle" fill="white" font-size="42" font-family="Arial">ComicCraft Panel {index}</text></svg>'''
 Path(path).write_text(svg,encoding='utf-8')
def generate(prompt,index):
 Path(GENERATED_DIR).mkdir(exist_ok=True)
 out=Path(GENERATED_DIR)/f'panel_{index}.png'
 if HF_TOKEN:
  import requests
  r=requests.post(f'https://api-inference.huggingface.co/models/{HF_IMAGE_MODEL}',headers={'Authorization':f'Bearer {HF_TOKEN}'},json={'inputs':prompt},timeout=120)
  if r.ok and r.headers.get('content-type','').startswith('image'):out.write_bytes(r.content);return str(out)
 svg=out.with_suffix('.svg');fallback(svg,index);return str(svg)
